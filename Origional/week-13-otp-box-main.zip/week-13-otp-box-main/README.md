Things to learn
1. Transitions
2. Creating sidebars
3. Absolute/fixed/relative positioning
4. Completing the design
5. Dark Mode, hover effects. (https://tailwindcss.com/docs/dark-mode#basic-usage)