
export const Sidebar2Transition = () => {
    return <div>
        <button className="transition-all duration-1000 bg-red-200 hover:bg-green-200 p-4 hover:p-8">hi there</button>
    </div>
}