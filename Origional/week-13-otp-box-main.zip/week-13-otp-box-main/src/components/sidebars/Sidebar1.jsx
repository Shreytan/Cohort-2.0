
export const Sidebar1 = () => {
    return <div>
        <div className="fixed top-0 left-0 w-64 bg-white h-screen md:visible invisible">
            hi there
        </div>
        <div className="ml-0 md:ml-64">
            hello
        </div>
    </div>
}